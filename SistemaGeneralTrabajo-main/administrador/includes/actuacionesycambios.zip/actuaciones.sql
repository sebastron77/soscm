CREATE TABLE `actuaciones` (
  `id` int(11) NOT NULL,
  `folio_actuacion` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_captura_acta` date NOT NULL,
  `catalogo` varchar(250) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(500) COLLATE utf8_spanish_ci DEFAULT NULL,
  `autoridades` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `autoridades_federales` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `peticion` varchar(250) COLLATE utf8_spanish_ci NOT NULL,
  `adjunto` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_creacion_sistema` date NOT NULL,
  `area_creacion` varchar(250) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

ALTER TABLE `actuaciones`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `actuaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
COMMIT;