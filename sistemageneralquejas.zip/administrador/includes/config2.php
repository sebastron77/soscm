<?php

  define( 'DB_HOST2', 'localhost' );       // Host de la BD
  define( 'DB_USER2', 'root' );            // Usuario de la BD
  define( 'DB_PASS2', '' );          // Password de la BD
  define( 'DB_NAME2', 'pruebaquejas' ); // Nombre de la BD

?>